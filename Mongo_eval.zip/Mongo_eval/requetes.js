//Exo2

//Ecrire une requête qui renvoie les prénoms des joueurs dont le nomest ‘Dupont’.
db.players.find({ lastname: 'Dupont' })

// Ecrire une requête qui modifie le mot de passe de Dorine Dupont, son
// nouveau mot de passe étant 1976.
db.players.updateOne({ firstname: 'Dorine', lastname: 'Dupont' }, { $set: { password: '1976' } })

// Ecrire une requête permettant d’ajouter le nouveau membre « Zora
// MAGID » dont le login est « zora » et le mot de passe 2021.
db.players.insertOne({ firstname: 'Zora', lastname: 'MAGID', login: 'zora', password: '2021' })

// Déterminer le jour et la plage horaire du match entre Durand Belina et
// Caron Camilia.

db.matches.find({ 
    $and: [
      { $or: [{ id_joueur1: 'Durand Belina' }, { id_joueur2: 'Durand Belina' }] },
      { $or: [{ id_joueur1: 'Caron Camilia' }, { id_joueur2: 'Caron Camilia' }] }
    ]
  }, { date: 1, id_creneau: 1, _id: 0 })

//   Déterminer le nom des deux joueurs qui sont les seuls à avoir joué
//   dans le “hangar”.
  
db.matches.aggregate([
{ $match: { id_terrain: 'hangar' } },
{ $group: { _id: null, players: { $addToSet: '$id_joueur1' } } },
{ $unwind: '$players' },
{ $group: { _id: null, players: { $addToSet: '$players' } } },
{ $match: { $expr: { $eq: [{ $size: '$players' }, 2] } } }
])

// exo3
//1
db.matches.aggregate([
    { $group: { _id: "$id_terrain", count: { $sum: 1 } } }
]);

//2
db.matches.aggregate([
{ $group: { _id: "$id_creneau", count: { $sum: 1 } } },
{ $sort: { count: -1 } },
{ $limit: 1 }
]);
//3
db.matches.aggregate([
    { $unwind: "$id_joueur1" },
    { $unwind: "$id_joueur2" },
    { $group: { _id: { $cond: { if: { $eq: ["$id_joueur1", "$id_joueur2"] }, then: "$id_joueur1", else: { $concatArrays: ["$id_joueur1", "$id_joueur2"] } } }, count: { $sum: 1 } } },
    { $sort: { count: 1 } },
    { $limit: 1 }
]);

//4
db.matches.aggregate([
{ $group: { _id: "$id_terrain", count: { $sum: 1 } } },
{ $sort: { count: -1 } },
{ $limit: 1 }
]);
