require('dotenv').config();
const express = require('express');
const mongoose = require('mongoose');
const app = express();

app.use(express.json());

// models import
const Player = require('./models/players');
const Court = require('./models/court');
const Timeslot = require('./models/timeslot');
const Reservation = require('./models/reservations');



async function initializeDatabase() {
  // Insert random data 
  await insertRandomPlayers(10); 
  await insertRandomCourts(5); 
  await insertRandomTimeslots(5); 
  await insertRandomReservations(10); 
  console.log('Database initialized with random data.');
}

async function insertRandomPlayers(count) {
  for (let i = 0; i < count; i++) {
    const player = new Player({
      firstname: `Firstname${i}`,
      lastname: `Lastname${i}`,
      login: `login${i}`,
      password: `password${i}`,
    });
    await player.save();
  }
}

async function insertRandomCourts(count) {
    for (let i = 0; i < count; i++) {
      const court = new Court({
        name: `Court${i}`, // Modification ici pour correspondre au champ requis dans le modèle
        surface: `Surface${i % 3}`,
      });
      await court.save();
    }
  }
  
async function insertRandomTimeslots() {
  const timeslots = ['08:00', '10:00', '12:00', '14:00', '16:00', '18:00'];
  timeslots.forEach(async (slot) => {
    const timeslot = new Timeslot({ timeslot: slot });
    await timeslot.save();
  });
}

async function insertRandomReservations(count) {
  const players = await Player.find();
  const courts = await Court.find();
  const timeslots = await Timeslot.find();

  for (let i = 0; i < count; i++) {
    const reservation = new Reservation({
      players: [players[i % players.length]._id, players[(i + 1) % players.length]._id],
      courtId: courts[i % courts.length]._id,
      date: new Date(2024, 0, i + 1), 
      timeslotId: timeslots[i % timeslots.length]._id,
    });
    await reservation.save();
  }
}


// MongoDB connection
mongoose.connect(process.env.MONGO_URL)
  .then(() => {
    console.log('Connexion à MongoDB réussie.');
    initializeDatabase(); 
  })
  .catch(err => console.error('Échec de connexion à MongoDB', err));