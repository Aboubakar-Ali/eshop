const mongoose = require('mongoose');

const playerSchema = mongoose.Schema({
    lastname: { type: String, required: true },
    firstname: { type: String, required: true },
    login: { type: String, required: true, unique: true },
    password: { type: String, required: true }
  });

module.exports = mongoose.model('Player', playerSchema);
