const mongoose = require('mongoose');

const courtSchema = mongoose.Schema({
  name: { type: String, required: true },
  surface: { type: String, required: true }
});

module.exports = mongoose.model('Court', courtSchema);
