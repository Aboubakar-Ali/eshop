const mongoose = require('mongoose');

const timeslotSchema = mongoose.Schema({
    timeslot: { type: String, required: true }
});

module.exports = mongoose.model('timeslot', timeslotSchema);
