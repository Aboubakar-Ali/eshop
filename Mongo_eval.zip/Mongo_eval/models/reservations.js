const mongoose = require('mongoose');

const reservationSchema = mongoose.Schema({
  players: [{ type: mongoose.Schema.Types.ObjectId, ref: 'Player', required: true }],
  courtId: { type: mongoose.Schema.Types.ObjectId, ref: 'Court', required: true },
  date: { type: Date, required: true },
  timeslotId: { type: mongoose.Schema.Types.ObjectId, ref: 'timeslot', required: true }
});

module.exports = mongoose.model('Reservation', reservationSchema);
